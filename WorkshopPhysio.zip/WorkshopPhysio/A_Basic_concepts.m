

% Here we see the basic concepts to know for collecting and analyzing good
% physiological data




clc
clear
close all




%% Understanding sampling frequency
fs = 500; 
eda = load("eda.mat"); eda = eda.eda; eda_smooth = movmean(eda, 300);

duration = numel(eda)/fs;
t = linspace(0, duration, numel(eda));

figure('position', [300, 200, 1000, 600]);
plot(t, eda_smooth, 'k.')
xlabel('Time (s)')
ylabel('uSiemens')
title('Electrodermal activity (EDA) - 500 Hz fs')



%% Suppose we sampled it at other sampling frequency
new_fs = 0.5; % change it here

eda_10 = downsample(eda_smooth, fs/new_fs);
duration = numel(eda_10)/new_fs;
t2 = linspace(0, duration, numel(eda_10));

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_smooth, 'k.')
xlabel('Time (s)')
ylabel('uSiemens')
title('Electrodermal activity (EDA) - 500 Hz fs')

subplot(212)
plot(t2, eda_10, 'k.')
xlabel('Time (s)')
ylabel('uSiemens')
title(sprintf('Electrodermal activity (EDA) - %1.0d Hz fs', new_fs))
linkaxes


whos eda
whos eda_10




%% Create one-cycle sinusoid
fs = 1000; % Sampling frequency (Hz)
f1 = 1; % Frequency of sinusoid (Hz)

t = 0:1/fs:1; % Time vector (1 second)
y1 = sin(2*pi*f1*t); % Generate sine wave

figure('position', [300, 200, 1000, 600]);
plot(t, y1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Pure Sinusoidal Wave (1 Hz)');
grid on;
hold on
yline(0)





%% Create pure sinusoid
fs = 1000; % Sampling frequency (Hz)
f1 = 4; % Frequency of sinusoid (Hz

t = 0:1/fs:1; % Time vector (1 second))
y1 = sin(2*pi*f1*t); % Generate sine wave

figure('position', [300, 200, 1000, 600]);
plot(t, y1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Pure Sinusoidal Wave (x Hz)');
grid on;
hold on
yline(0)



%% Plot spectrum
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, y1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Pure Sinusoidal Wave (x Hz)');
grid on;
hold on
yline(0)

subplot(212)
x = zeros(fs/2,1);
x(f1) = 1;
bar(1:fs/2, x);
xlim([0 25])
ylim([0 1.2])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
title('Frequency Spectrum')


%% Add a second frequency
f2 = 20; % Another frequency (Hz)

y2 = sin(2*pi*f2*t);
combined = y1 + y2; % Sum of two sinusoids

figure('position', [300, 200, 1000, 600]);
plot(t, combined, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Combination of x Hz and y Hz Signals');
grid on;

%% Overlay f1
hold on
plot(t, y1, 'r', 'LineWidth', 1.2);

%% Overlay f2
plot(t, y2, 'b:', 'LineWidth', 1.2)


%% Plot separately
figure('position', [300, 200, 1000, 600]);

subplot(311)
plot(t, y1, 'r', 'LineWidth', 1.2);
subplot(312)
plot(t, y2, 'b:', 'LineWidth', 1.2)
subplot(313)
plot(t, combined, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Combination of x Hz and y Hz Signals');
grid on;

%% Plot spectrum
figure
subplot(211)
plot(t, combined, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Pure Sinusoidal Wave (x Hz)');
grid on;
hold on
yline(0)

subplot(212)
x = zeros(fs/2,1);
x([f1, f2]) = 0.5;
bar(1:fs/2, x);
xlim([0 25])
ylim([0 1.2])
xlabel('Frequency (Hz)')
ylabel('Magnitude')
title('Frequency Spectrum')

%% Add noise
noise = 0.3 * randn(size(t)); % Gaussian noise
linenoise = sin(2*pi*50*t); % Line noise (50 Hz)

noisy_signal = combined + noise + linenoise;

figure('position', [300, 200, 1000, 600]);
plot(t, noisy_signal, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('Amplitude');
title('Noisy Signal');
grid on;

%% Fourier decomposition - complete power spectrum
Y = fft(noisy_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum');
grid on;



%% Low-pass Filter
fc = 1; % Cutoff frequency

[b, a] = butter(4, fc/(fs/2), 'low'); % Low-pass filter
filtered_signal = filtfilt(b, a, noisy_signal);

% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);

subplot(211)
plot(t, noisy_signal, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Amplitude');
title('Filtered Signal (Low-Pass)');
grid on;

subplot(212)
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (Low-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)




%% High-pass Filter
fc = 35; % Cutoff frequency

[b, a] = butter(4, fc/(fs/2), 'high'); % Low-pass filter
filtered_signal = filtfilt(b, a, noisy_signal);


% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, noisy_signal, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('Amplitude');
title('Filtered Signal (High-Pass)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (High-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)







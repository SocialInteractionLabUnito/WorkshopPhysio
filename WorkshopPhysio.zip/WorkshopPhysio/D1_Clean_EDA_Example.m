

clc
clear
close all




%% Load EDA signal
fs = 500; 
eda = load("eda.mat"); eda = eda.eda;
duration = numel(eda)/fs;
t = linspace(0, duration, numel(eda));

%% Plot signal and spectrum

% Fourier decomposition
Y = fft(eda);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);

subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Electrodermal activity (EDA)');
grid on;

subplot(212)
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum');
grid on;
ylim([0, 0.03])





%% Low-pass Filter
fc = 0.5; % Cutoff frequency

[b, a] = butter(4, fc/(fs/2), 'low'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);

% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);

subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Low-Pass)');
grid on;

subplot(212)
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (Low-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)




%% High-pass Filter
fc = 0.01; % Cutoff frequency

[b, a] = butter(4, fc/(fs/2), 'high'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);


% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (High-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;




%% Apply band-pass filter

fc = [0.01, 0.5]; % Cutoff frequencies


[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);


% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (High-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;






%% Suppose EDA has strong line noise (50 Hz noise)
linenoise = 0.01.*sin(2*pi*50*t); % Line noise (50 Hz)
eda_noisy = eda + linenoise';


% Fourier decomposition
Y = fft(eda_noisy);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Noisy EDA');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum');
grid on;



%% Apply band-stop filter

fc = [48, 52]; % Cutoff frequencies
[b, a] = butter(1, fc/(fs/2), 'stop'); % Low-pass filter

filtered_signal = filtfilt(b, a, eda_noisy);

% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-stop)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (Band-stop)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-stop at 50 Hz)');
grid on;




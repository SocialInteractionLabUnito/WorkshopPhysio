


clc
clear
close all

%% Load EDA signal
fs = 500; 
eda1 = load("eda.mat"); eda1 = eda1.eda;
eda2 = load("eda2.mat"); eda2 = eda2.eda; 
eda2 = eda2 + 3.5;

eda1(isnan(eda2)) = [];
eda2(isnan(eda2)) = [];
duration = numel(eda1)/fs;
t = linspace(0, duration, numel(eda1));

eda2(20*fs:end-40*fs) = eda2(20*fs:end-40*fs) + [linspace(0, .055*mean(eda2), numel(eda2(20*fs:end-40*fs)))]';
eda2 = movmean(eda2, 2000); + 0.001*rand(numel(eda2),1);





%% Plot raw signals
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
grid on;

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
grid on;


%% Plot on the same scale
figure('position', [300, 200, 1000, 600]);
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');



%%                                      Signals corrections
%------------------------------------------------------------------------------------------------

%% 1. Apply band-pass filters
fc = [0.01, 0.5]; % Cutoff frequencies

% EDA 1
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda1_filt = filtfilt(b, a, eda1);


% EDA 2
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda2_filt = filtfilt(b, a, eda2);


% Plot
figure('position', [300, 200, 1000, 600]);
plot(t, eda1_filt, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_filt, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');



%% 2. Zscore
% Plot
eda1_zscored = ( eda1 - mean(eda1) ) ./ std(eda1);
eda2_zscored = ( eda2 - mean(eda2) ) ./ std(eda2);

figure('position', [300, 200, 1000, 600]);
plot(t, eda1_zscored, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_zscored, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('z-scored signal');
ylim([-3, 5])




%% 3. Filter AND Zscore 
% Plot
eda1_zscored = ( eda1_filt - mean(eda1_filt) ) ./ std(eda1_filt);
eda2_zscored = ( eda2_filt - mean(eda2_filt) ) ./ std(eda2_filt);

figure('position', [300, 200, 1000, 600]);
plot(t, eda1_zscored, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_zscored, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('filtered and z-scored signal');
ylim([-3, 5])



%% 4. Baseline correction - subtract baseline

bl_start = 0; % Seconds
bl_end = 20;

idx = t >= bl_start & t <= bl_end;

m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

eda1_bl_corr = eda1 - m1;
eda2_bl_corr = eda2 - m2;

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
xline(bl_end, 'k:', 'LineWidth',2)

subplot(212)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_bl_corr, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Baseline-corrected');
xline(bl_end, 'k:', 'LineWidth',2)



%% 5. Filter AND Baseline-correct

bl_start = 0; % Seconds
bl_end = 20;

idx = t >= bl_start & t <= bl_end;

m1 = mean(eda1_filt(idx));
m2 = mean(eda2_filt(idx));

eda1_bl_corr = eda1_filt - m1;
eda2_bl_corr = eda2_filt - m2;

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
xline(bl_end, 'k:', 'LineWidth',2)

subplot(212)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_bl_corr, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Baseline-corrected');
xline(bl_end, 'k:', 'LineWidth',2)











%%                                  Signals analysis
%------------------------------------------------------------------------------------------------



%% Tonic activity (1) 
%-----------------
% Suppose we have a baseline and a period of interest with continuous
% exposure to an event



% Get tonic of bl and epoch and then subtract the two values

period_time = [30, 150];

% Re-plot raw signals with bl and stimuli
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)


%% Add the lines

% Get mean of the baseline and mean of the epoch of interest, then subtract
bl_start = 0; % Seconds
bl_end = 20;

% Mean baseline
idx = t >= bl_start & t <= bl_end;
m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

% Mean epoch
idx = t >= period_time(1) & t <= period_time(2);
m1_epoch = mean(eda1(idx));
m2_epoch = mean(eda2(idx));

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m1, m1], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m1_epoch, m1_epoch], 'color', 'r', 'linewidth', 2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m2, m2], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m2_epoch, m2_epoch], 'color', 'r', 'linewidth', 2)



%% Bar plot
figure
bar([m1_epoch - m1, m2_epoch - m2])
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Tonic EDA: Stimulus - Baseline')


%% Tonic activity (2)
%-----------------
% Baseline-correct the signals, then get the corrected epoch value

% Get mean of the baseline and mean of the epoch of interest
bl_start = 0; % Seconds
bl_end = 20;

% Mean baseline
idx = t >= bl_start & t <= bl_end;
m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

% Correct
eda1_bl_corr = eda1 - m1;
eda2_bl_corr = eda2 - m2;

% Mean baseline after correction
m1_bl = mean(eda1_bl_corr(idx));
m2_bl = mean(eda2_bl_corr(idx));

% Mean epoch
idx = t >= period_time(1) & t <= period_time(2);
m1_epoch = mean(eda1_bl_corr(idx));
m2_epoch = mean(eda2_bl_corr(idx));


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m1_bl,m1_bl], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m1_epoch, m1_epoch], 'color', 'r', 'linewidth', 2)

subplot(212)
plot(t, eda2_bl_corr, 'b', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m2_bl,m2_bl], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m2_epoch, m2_epoch], 'color', 'r', 'linewidth', 2)



%% Bar plot
figure
bar([m1_epoch - m1_bl, m2_epoch - m2_bl])
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Tonic EDA: Stimulus - Baseline')






%% Phasic activity - i.e., peaks
%-----------------
clc
clear
close all

% Load EDA signal
fs = 500; 
eda1 = load("eda3.mat"); eda1 = eda1.eda;
eda1 = eda1 + 9;
eda2 = load("eda4.mat"); eda2 = eda2.eda; 
eda2 = eda2 + 3.5;

ibad = isnan(eda1) | isnan(eda2);
eda1(ibad) = [];
eda2(ibad) = [];

duration = numel(eda1)/fs;
t = linspace(0, duration, numel(eda1));

eda1 = eda1 + [mean(eda1).*2*pi*0.00001*t]';
eda2 = movmean(eda2, 1000); + 0.001*rand(numel(eda2),1);


%% Suppose we have a baseline and several stimuli
% Get mean of the baseline and mean of the epoch of interest
bl_start = 0; % Seconds
bl_end = 2;
stim_times = [10, 20, 38, 55, 94, 118, 133];

% Re-plot raw signals with bl and stimuli
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)


%% Apply band-pass filter

fc = [0.01, 0.5]; % Cutoff frequencies

% EDA 1
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda1_filt = filtfilt(b, a, eda1);

% EDA 2
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda2_filt = filtfilt(b, a, eda2);


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1_filt, 'k', 'LineWidth', 2);
hold on
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1 filtered');
grid on;
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2_filt, 'b', 'LineWidth', 2);
hold on
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2 filtered');
grid on;
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)



%% Plot individual peaks
figure('position', [300, 200, 1000, 600]);
offset_1 = -3;
offset_2 = 10;
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    plot(tx, eda1_filt(idx), 'k', 'LineWidth',2);
    hold on
    plot(tx, eda2_filt(idx), 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    title(sprintf('Stimulus %1d', i))
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    pause
end



%% Plot individual peaks aligned to their own baseline
figure('position', [300, 200, 1000, 600]);
offset_1 = -3;
offset_2 = 10;
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    y1 = eda1_filt(idx); y1 = y1 - mean(y1(1:abs(offset_1)*fs));
    y2 = eda2_filt(idx); y2 = y2 - mean(y2(1:abs(offset_1)*fs));
    plot(tx, y1, 'k', 'LineWidth',2);
    hold on
    plot(tx, y2, 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    title(sprintf('Stimulus %1d', i))
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    pause
end



%% On the latter, we compute the peak height
figure('position', [100, 200, 1200, 600]);
offset_1 = -3;
offset_2 = 10;

peak_amp_eda1 = [];
peak_amp_eda2 = [];
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    y1 = eda1_filt(idx); y1 = y1 - mean(y1(1:abs(offset_1)*fs));
    y2 = eda2_filt(idx); y2 = y2 - mean(y2(1:abs(offset_1)*fs));
    [pk1, ploc1] = findpeaks(y1(tx>0), 'MinPeakProminence',0.005, 'NPeaks',1);
    [pk2, ploc2] = findpeaks(y2(tx>0), 'MinPeakProminence',0.005, 'NPeaks',1);
    plot(tx, y1, 'k', 'LineWidth',2);
    hold on
    plot(tx, y2, 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    title(sprintf('Stimulus %1d', i))
    scatter(ploc1/fs, pk1, 100, 'r', 'filled')
    scatter(ploc2/fs, pk2, 100, 'r', 'filled')
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    if isempty(pk1)
        peak_amp_eda1(i) = NaN;
    else
        peak_amp_eda1(i) = pk1;
    end
    if isempty(pk2)
        peak_amp_eda2(i) = NaN;
    else
        peak_amp_eda2(i) = pk2;
    end
    pause
end




%% Bar num peaks and mean peak amplitude


figure

subplot(211)
bar([sum(~isnan(peak_amp_eda1)), sum(~isnan(peak_amp_eda2))])
xticklabels({'EDA 1', 'EDA 2'})
ylim([0, numel(stim_times)+2])
ylabel('Count')
title('Number of peaks')

subplot(212)
y = [nanmean(peak_amp_eda1), nanmean(peak_amp_eda2)];
yerr = [sterr(peak_amp_eda1), sterr(peak_amp_eda2)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Mean peak amplitude')



%% We can also zscore the peak amplitudes after we xtracted them!

% Lets zscore
peak_amp_eda1_zscored = (peak_amp_eda1 - nanmean(peak_amp_eda1) ) ./ nanstd(peak_amp_eda1);
peak_amp_eda2_zscored = (peak_amp_eda2 - nanmean(peak_amp_eda2) ) ./ nanstd(peak_amp_eda2);

figure
y = [nanmean(peak_amp_eda1_zscored), nanmean(peak_amp_eda2_zscored)];
yerr = [sterr(peak_amp_eda1_zscored), sterr(peak_amp_eda2_zscored)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('z-score')
title('Mean peak amplitude')
hold on
text(1.3, 0.2, 'OPS!', 'FontSize', 20, 'Color', 'r')




%% We have to zscore ACROSS subjects/conditions

% Lets zscore
allPeaks = [peak_amp_eda1, peak_amp_eda2];

allPeaks_zscored = (allPeaks - nanmean(allPeaks) ) ./ nanstd(allPeaks);

peak_amp_eda1_zscored = allPeaks_zscored(1:numel(stim_times));
peak_amp_eda2_zscored = allPeaks_zscored(numel(stim_times)+1:end);


figure
y = [nanmean(peak_amp_eda1_zscored), nanmean(peak_amp_eda2_zscored)];
yerr = [sterr(peak_amp_eda1_zscored), sterr(peak_amp_eda2_zscored)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('z-score')
title('Mean peak amplitude (z-scored)')
hold on

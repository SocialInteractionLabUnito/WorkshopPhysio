


% Here we see examples of cleaning data of our Subj 01.
% Some cleaning steps will be repeated in the script called
% "03_Analyze_EDA_SnakeExperiment", where we will also analyze tonic and
% phasic activities after cleaning






clc
clear
close all




% Load EDA signal

% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 11, "Encoding", "UTF-8");

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["INFO", "VarName2", "VarName3", "VarName4", "VarName5", "VarName6", "VarName7", "VarName8", "VarName9", "VarName10", "VarName11"];
opts.VariableTypes = ["double", "double", "string", "string", "string", "string", "string", "double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Specify variable properties
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "EmptyFieldRule", "auto");
opts = setvaropts(opts, "VarName8", "TrimNonNumeric", true);
opts = setvaropts(opts, "VarName8", "ThousandsSeparator", ",");

% Import the data
data = readtable("C:\Users\Lab_neurofisio\Desktop\WorkshopPhysio\Subj_01.csv", opts);
clear opts




% Get data
fs = 500;
eda = data{:,11};
eda(eda==5)=NaN;
eda(isnan(eda)) = [];


idx = find(data{:,4} == "StartSlide");
evnames = ["Snake", "Control", "Snake", "Snake", "Control", "Control", "Snake", "Control", "Snake"];
duration = numel(eda)/fs;




% Plot experiment
t = linspace(0, duration, numel(eda));
figure('position', [300, 200, 1000, 600]); hold on
plot(t, eda, 'k', 'LineWidth',2)
xline(idx/fs, 'r')
text(idx/fs, max(eda)*ones(numel(idx),1), evnames, 'color', 'r')
xlabel('Time')
ylabel('ms')




%% Plot signal and spectrum

% Fourier decomposition
Y = fft(eda);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);

subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Electrodermal activity (EDA)');
grid on;

subplot(212)
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum');
grid on;
ylim([0, 0.03])





%% Low-pass Filter
fc = 0.5; % Cutoff frequency

[b, a] = butter(4, fc/(fs/2), 'low'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);

% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);

P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;

figure('position', [300, 200, 1000, 600]);

subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Low-Pass)');
grid on;

subplot(212)
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (Low-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)




%% High-pass Filter
fc = 0.01; % Cutoff frequency

[b, a] = butter(1, fc/(fs/2), 'high'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);


% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (High-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;




%% Apply band-pass filter

fc = [0.01, 0.5]; % Cutoff frequencies


[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
filtered_signal = filtfilt(b, a, eda);


% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (High-Pass)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (High-Pass)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;






%% Suppose EDA has strong line noise (50 Hz noise)
linenoise = 0.01.*sin(2*pi*50*t); % Line noise (50 Hz)
eda_noisy = eda + linenoise';


% Fourier decomposition
Y = fft(eda_noisy);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Noisy EDA');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum');
grid on;



%% Apply band-stop filter

fc = [48, 52]; % Cutoff frequencies
[b, a] = butter(1, fc/(fs/2), 'stop'); % Low-pass filter

filtered_signal = filtfilt(b, a, eda_noisy);

% Fourier decomposition
Y = fft(filtered_signal);
L = length(t);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(L/2))/L;



figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
hold on
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-stop)');
grid on;

subplot(212);
bar(f, P1);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Spectrum (Band-stop)');
grid on;
hold on
xline(fc, 'r', 'LineWidth',2)


% Lets plot them separately

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda_noisy, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;

subplot(212)
plot(t, filtered_signal, 'r', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-stop at 50 Hz)');
grid on;





clc
clear
close all




% Load EDA signal

% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 11, "Encoding", "UTF-8");

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["INFO", "VarName2", "VarName3", "VarName4", "VarName5", "VarName6", "VarName7", "VarName8", "VarName9", "VarName10", "VarName11"];
opts.VariableTypes = ["double", "double", "string", "string", "string", "string", "string", "double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Specify variable properties
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "EmptyFieldRule", "auto");
opts = setvaropts(opts, "VarName8", "TrimNonNumeric", true);
opts = setvaropts(opts, "VarName8", "ThousandsSeparator", ",");

% Import the data
data = readtable("C:\Users\Lab_neurofisio\Desktop\WorkshopPhysio\Subj_01.csv", opts);
clear opts




% Load EDA signal

% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 11, "Encoding", "UTF-8");

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["INFO", "VarName2", "VarName3", "VarName4", "VarName5", "VarName6", "VarName7", "VarName8", "VarName9", "VarName10", "VarName11"];
opts.VariableTypes = ["double", "double", "string", "string", "string", "string", "string", "double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Specify variable properties
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["VarName3", "VarName4", "VarName5", "VarName6", "VarName7"], "EmptyFieldRule", "auto");
opts = setvaropts(opts, "VarName8", "TrimNonNumeric", true);
opts = setvaropts(opts, "VarName8", "ThousandsSeparator", ",");

% Import the data
data2 = readtable("C:\Users\Lab_neurofisio\Desktop\WorkshopPhysio\Subj_02.csv", opts);
clear opts



% Get data
buffer_base = 10;
fs = 500;

eda1 = data{:,11};
eda1(eda1==5)=NaN;
eda1(isnan(eda1)) = [];
eda1 = [eda1(end-buffer_base*fs:end); eda1];

eda2 = data2{:,11};
eda2(eda2==5)=NaN;
eda2(isnan(eda2)) = [];
eda2 = [1.2*eda2(end-buffer_base*fs:end); eda2];


idx = find(data{:,4} == "StartSlide");
idx = idx + buffer_base*fs;
evnames = ["Snake", "Control", "Snake", "Snake", "Control", "Control", "Snake", "Control", "Snake"];
duration = numel(eda1)/fs;
duration = duration + buffer_base;
stim_times = idx/fs;

[minval, minidx] = min([numel(eda1), numel(eda2)]);
eda1 = eda1(1:numel(eda2));


% Plot experiment
t = linspace(0, duration, numel(eda1));
figure('position', [300, 200, 1000, 600]); hold on
plot(t, eda1, 'k', 'LineWidth',2)
plot(t, eda2, 'b', 'LineWidth',2)
xline(idx/fs, 'r')
text(idx/fs, max(eda1)*ones(numel(idx),1), evnames, 'color', 'r')
xlabel('Time')
ylabel('ms')






%% Plot raw signals
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
grid on;

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
grid on;


%% Plot on the same scale
figure('position', [300, 200, 1000, 600]);
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');



%%                                      Signals corrections
%------------------------------------------------------------------------------------------------

%% 1. Apply band-pass filters
fc = [0.01, 5]; % Cutoff frequencies

% EDA 1
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda1_filt = filtfilt(b, a, eda1);


% EDA 2
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda2_filt = filtfilt(b, a, eda2);


% Plot
figure('position', [300, 200, 1000, 600]);
plot(t, eda1_filt, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_filt, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');



%% 2. Zscore
% Plot
eda1_zscored = ( eda1 - mean(eda1) ) ./ std(eda1);
eda2_zscored = ( eda2 - mean(eda2) ) ./ std(eda2);

figure('position', [300, 200, 1000, 600]);
plot(t, eda1_zscored, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_zscored, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('z-scored signal');
ylim([-3, 5])




%% 3. Filter AND Zscore 
% Plot
eda1_zscored = ( eda1_filt - mean(eda1_filt) ) ./ std(eda1_filt);
eda2_zscored = ( eda2_filt - mean(eda2_filt) ) ./ std(eda2_filt);

figure('position', [300, 200, 1000, 600]);
plot(t, eda1_zscored, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_zscored, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('z-score');
title('filtered and z-scored signal');
ylim([-3, 5])



%% 4. Baseline correction - subtract baseline

bl_start = 0; % Seconds
bl_end = buffer_base;

idx = t >= bl_start & t <= bl_end;

m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

eda1_bl_corr = eda1 - m1;
eda2_bl_corr = eda2 - m2;

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
xline(bl_end, 'k:', 'LineWidth',2)

subplot(212)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_bl_corr, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Baseline-corrected');
xline(bl_end, 'k:', 'LineWidth',2)



%% 5. Filter AND Baseline-correct

bl_start = 0; % Seconds
bl_end = buffer_base;

idx = t >= bl_start & t <= bl_end;

m1 = mean(eda1_filt(idx));
m2 = mean(eda2_filt(idx));

eda1_bl_corr = eda1_filt - m1;
eda2_bl_corr = eda2_filt - m2;

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
grid on;
hold on
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Raw Signal');
xline(bl_end, 'k:', 'LineWidth',2)

subplot(212)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Filtered Signal (Band-Pass)');
grid on;
hold on
plot(t, eda2_bl_corr, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('Baseline-corrected');
xline(bl_end, 'k:', 'LineWidth',2)











%%                                  Signals analysis
%------------------------------------------------------------------------------------------------



%% Tonic activity (1) 
%-----------------
% Suppose we have a baseline and a period of interest with continuous
% exposure to an event



% Get tonic of bl and epoch and then subtract the two values

period_time = [30, 100];

% Re-plot raw signals with bl and stimuli
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)


%% Add the lines

% Get mean of the baseline and mean of the epoch of interest, then subtract
bl_start = 0; % Seconds
bl_end = buffer_base;

% Mean baseline
idx = t >= bl_start & t <= bl_end;
m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

% Mean epoch
idx = t >= period_time(1) & t <= period_time(2);
m1_epoch = mean(eda1(idx));
m2_epoch = mean(eda2(idx));

figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m1, m1], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m1_epoch, m1_epoch], 'color', 'r', 'linewidth', 2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m2, m2], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m2_epoch, m2_epoch], 'color', 'r', 'linewidth', 2)



%% Bar plot
figure
bar([m1_epoch - m1, m2_epoch - m2])
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Tonic EDA: Stimulus - Baseline')


%% Tonic activity (2)
%-----------------
% Baseline-correct the signals, then get the corrected epoch value

% Get mean of the baseline and mean of the epoch of interest
bl_start = 0; % Seconds
bl_end = buffer_base;

% Mean baseline
idx = t >= bl_start & t <= bl_end;
m1 = mean(eda1(idx));
m2 = mean(eda2(idx));

% Correct
eda1_bl_corr = eda1 - m1;
eda2_bl_corr = eda2 - m2;

% Mean baseline after correction
m1_bl = mean(eda1_bl_corr(idx));
m2_bl = mean(eda2_bl_corr(idx));

% Mean epoch
idx = t >= period_time(1) & t <= period_time(2);
m1_epoch = mean(eda1_bl_corr(idx));
m2_epoch = mean(eda2_bl_corr(idx));


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1_bl_corr, 'k', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m1_bl,m1_bl], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m1_epoch, m1_epoch], 'color', 'r', 'linewidth', 2)

subplot(212)
plot(t, eda2_bl_corr, 'b', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(period_time, 'r:', 'LineWidth',2)
line([bl_start, bl_end], [m2_bl,m2_bl], 'color', 'k', 'linewidth', 2)
line([period_time(1), period_time(2)], [m2_epoch, m2_epoch], 'color', 'r', 'linewidth', 2)



%% Bar plot
figure
bar([m1_epoch - m1_bl, m2_epoch - m2_bl])
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Tonic EDA: Stimulus - Baseline')






%% Phasic activity - i.e., peaks


%% Suppose we have a baseline and several stimuli
% Get mean of the baseline and mean of the epoch of interest
bl_start = 0; % Seconds
bl_end = buffer_base;

% Re-plot raw signals with bl and stimuli
figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1, 'k', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2');
hold on
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)


%% Apply band-pass filter

fc = [0.01, 0.5]; % Cutoff frequencies

% EDA 1
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda1_filt = filtfilt(b, a, eda1);

% EDA 2
[b, a] = butter(1, fc/(fs/2), 'bandpass'); % Low-pass filter
eda2_filt = filtfilt(b, a, eda2);


figure('position', [300, 200, 1000, 600]);
subplot(211)
plot(t, eda1_filt, 'k', 'LineWidth', 2);
hold on
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 1 filtered');
grid on;
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)

subplot(212)
plot(t, eda2_filt, 'b', 'LineWidth', 2);
hold on
xlabel('Time (s)');
ylabel('uSiemens');
title('EDA 2 filtered');
grid on;
xline(bl_end, 'k:', 'LineWidth',2)
xline(stim_times, 'r:', 'LineWidth',2)



%% Plot individual peaks
figure('position', [300, 200, 1000, 600]);
offset_1 = -3;
offset_2 = 14;
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    plot(tx, eda1_filt(idx), 'k', 'LineWidth',2);
    hold on
    plot(tx, eda2_filt(idx), 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    yline(0)
    title(evnames(i))
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    disp('Press enter here to continue plotting peaks')
    pause
end



%% Plot individual peaks ON THE SAME SCALE
figure('position', [300, 200, 1000, 600]);
offset_1 = -3;
offset_2 = 14;
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    plot(tx, eda1_filt(idx), 'k', 'LineWidth',2);
    hold on
    plot(tx, eda2_filt(idx), 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    yline(0)
    title(evnames(i))
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    ylim([ -.3, .4])
    disp('Press enter here to continue plotting peaks')
    pause
end


%% Plot individual peaks aligned to their own baseline
figure('position', [300, 200, 1000, 600]);
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    y1 = eda1_filt(idx); y1 = y1 - mean(y1(1:abs(offset_2)*fs));
    y2 = eda2_filt(idx); y2 = y2 - mean(y2(1:abs(offset_2)*fs));
    plot(tx, y1, 'k', 'LineWidth',2);
    hold on
    plot(tx, y2, 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    title(evnames(i))
    xlabel('Time from stimulus (s)')
    ylabel('uSiemens')
    yline(0)
    disp('Press enter here to continue plotting peaks')
    pause
end



%% On the latter, we compute the peak height
figure('position', [100, 200, 1200, 600]);

peak_amp_eda1 = [];
peak_amp_eda2 = [];
for i = 1:numel(stim_times)
    it = knnsearch(t', stim_times(i), 'k', 1);
    idx = it + offset_1*fs : it + offset_2*fs;
    tx = t(idx) - min(t(idx)) + offset_1;
    cla
    y1 = eda1_filt(idx); y1 = y1 - mean(y1(1:abs(offset_1)*fs));
    y2 = eda2_filt(idx); y2 = y2 - mean(y2(1:abs(offset_1)*fs));
    [pk1, ploc1] = findpeaks(y1(tx>0), 'MinPeakProminence',0.01);
    [~, imax1] = max(pk1);
    [pk2, ploc2] = findpeaks(y2(tx>0), 'MinPeakProminence',0.01);
    [~, imax2] = max(pk2);
    plot(tx, y1, 'k', 'LineWidth',2);
    hold on
    plot(tx, y2, 'b', 'LineWidth',2);
    xline(0, 'r:', 'LineWidth',2)
    title(evnames(i))
    scatter(ploc1(imax1)/fs+0.5, pk1(imax1), 4000, 'r')
    scatter(ploc2(imax2)/fs+0.5, pk2(imax2), 4000, 'r')
    xlabel('Time from stimulus (s)')
    yline(0)
    ylabel('uSiemens')
    if isempty(pk1)
        peak_amp_eda1(i) = NaN;
    else
        peak_amp_eda1(i) = pk1(imax1);
    end
    if isempty(pk2)
        peak_amp_eda2(i) = NaN;
    else
        peak_amp_eda2(i) = pk2(imax2);
    end
    imax1 = [];
    imax2 = [];
    disp('Press enter here to continue plotting peaks')
    pause
end




%% Bar num peaks and mean peak amplitude


figure

subplot(211)
bar([sum(~isnan(peak_amp_eda1)), sum(~isnan(peak_amp_eda2))])
xticklabels({'EDA 1', 'EDA 2'})
ylim([0, numel(stim_times)+2])
ylabel('Count')
title('Number of peaks')

subplot(212)
y = [nanmean(peak_amp_eda1), nanmean(peak_amp_eda2)];
yerr = [sterr(peak_amp_eda1), sterr(peak_amp_eda2)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('uSiemens')
title('Mean peak amplitude')



%% We can also zscore the peak amplitudes after we xtracted them!

% Lets zscore
peak_amp_eda1_zscored = (peak_amp_eda1 - nanmean(peak_amp_eda1) ) ./ nanstd(peak_amp_eda1);
peak_amp_eda2_zscored = (peak_amp_eda2 - nanmean(peak_amp_eda2) ) ./ nanstd(peak_amp_eda2);

figure
y = [nanmean(peak_amp_eda1_zscored), nanmean(peak_amp_eda2_zscored)];
yerr = [sterr(peak_amp_eda1_zscored), sterr(peak_amp_eda2_zscored)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('z-score')
title('Mean peak amplitude')
hold on
text(1.3, 0.2, 'OPS!', 'FontSize', 20, 'Color', 'r')




%% We have to zscore ACROSS subjects/conditions

% Lets zscore
allPeaks = [peak_amp_eda1, peak_amp_eda2];

allPeaks_zscored = (allPeaks - nanmean(allPeaks) ) ./ nanstd(allPeaks);

peak_amp_eda1_zscored = allPeaks_zscored(1:numel(stim_times));
peak_amp_eda2_zscored = allPeaks_zscored(numel(stim_times)+1:end);


figure
y = [nanmean(peak_amp_eda1_zscored), nanmean(peak_amp_eda2_zscored)];
yerr = [sterr(peak_amp_eda1_zscored), sterr(peak_amp_eda2_zscored)];
bar(y)
hold on
errorbar(y, yerr, 'k', 'LineStyle','none')
xticklabels({'EDA 1', 'EDA 2'})
ylabel('z-score')
title('Mean peak amplitude (z-scored)')
hold on
